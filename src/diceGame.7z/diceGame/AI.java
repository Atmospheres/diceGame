package diceGame;

public class AI extends Player
{

	public AI()
	{
		isHuman = false;
	}
		
	
	
}
